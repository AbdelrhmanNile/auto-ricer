## auto ricer
A simple script to automatically rice bspwm, polybar, gtk, and more.